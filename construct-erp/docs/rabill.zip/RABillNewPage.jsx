// src/pages/qs/RABillNewPage.jsx
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  ArrowLeft, Save, Plus, AlertTriangle
} from 'lucide-react';
import { clsx } from 'clsx';
// FIX: Added missing measurementAPI import
import { raBillAPI, projectAPI, boqAPI, measurementAPI } from '../../api/client';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';

const inr = v => `₹${Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 0 })}`;

export default function RABillNewPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();

  const [formData, setFormData] = useState({
    project_id: '',
    bill_number: '',
    bill_date: dayjs().format('YYYY-MM-DD'),
    contractor_name: '',
    contractor_gstin: '',
    contractor_pan: '',
    work_description: '',
    bill_period_from: dayjs().startOf('month').format('YYYY-MM-DD'),
    bill_period_to: dayjs().format('YYYY-MM-DD'),
    retention_percent: 5,
    mobilization_advance_recovery: 0,
    remarks: '',
    gst_percent: 18,
    tds_rate: 2,
  });

  const [items, setItems] = useState([]);

  const { data: projects } = useQuery({
    queryKey: ['projects'],
    queryFn: () => projectAPI.list().then(r => r.data.data),
  });

  const { data: boqItems } = useQuery({
    queryKey: ['boq-summary', formData.project_id],
    queryFn: () => boqAPI.summary(formData.project_id).then(r => r.data.data),
    enabled: !!formData.project_id,
  });

  // FIX: measurementAPI was used but never imported — added to import above
  const { data: approvedMeasurements } = useQuery({
    queryKey: ['approved-measurements-hyper-sync', formData.project_id],
    queryFn: () =>
      measurementAPI.list().then(r => {
        const all = r.data.data || [];
        const pid = String(formData.project_id);
        return all.filter(m => {
          const mPid = String(m.project_id || m.projectId || m.project?.id || '');
          const isApproved = ['pm_approved', 'qs_approved', 'approved', 'Approved'].includes(m.status);
          return mPid === pid && isApproved;
        });
      }),
    enabled: !!formData.project_id,
  });

  const { data: previousStats } = useQuery({
    queryKey: ['project-billing-stats', formData.project_id],
    queryFn: () =>
      raBillAPI.list({ project_id: formData.project_id }).then(r => r.data.data),
    enabled: !!formData.project_id,
  });

  useEffect(() => {
    if (boqItems && Array.isArray(boqItems)) {
      const measurementMap = {};
      if (Array.isArray(approvedMeasurements)) {
        approvedMeasurements.forEach(m => {
          const bid = String(m.boq_item_id);
          if (!measurementMap[bid]) measurementMap[bid] = 0;
          measurementMap[bid] += parseFloat(m.net_quantity || 0);
        });
      }

      setItems(
        boqItems.map(it => {
          const bid = String(it.id);
          const prevBilled = parseFloat(it.certified_qty || 0);
          const totalApproved = measurementMap[bid] || 0;
          const claimable = Math.max(0, totalApproved - prevBilled);
          return {
            boq_item_id: it.id,
            description: it.description,
            unit: it.unit,
            rate: it.rate,
            boq_qty: it.quantity,
            prev_certified_qty: prevBilled,
            current_qty: claimable,
            amount: claimable * it.rate,
          };
        })
      );

      const count = (previousStats || []).length + 1;
      setFormData(prev => ({
        ...prev,
        bill_number:
          prev.bill_number ||
          `RA/${dayjs().format('YY')}/${String(count).padStart(2, '0')}`,
      }));
    }
  }, [boqItems, approvedMeasurements, previousStats]);

  const handleQtyChange = (idx, qty) => {
    const newItems = [...items];
    const it = newItems[idx];
    it.current_qty = parseFloat(qty || 0);
    it.amount = it.current_qty * it.rate;
    setItems(newItems);
  };

  const set = (key, val) => setFormData(p => ({ ...p, [key]: val }));

  // FIX: variable was named `totals` (singular misread as plural) — renamed to `grossTotal` for clarity
  const grossTotal = items.reduce((acc, it) => acc + (it.amount || 0), 0);
  const gstAmount = grossTotal * (formData.gst_percent / 100);
  const retentionAmount = grossTotal * (formData.retention_percent / 100);
  const netPayable =
    grossTotal + gstAmount - (retentionAmount + parseFloat(formData.mobilization_advance_recovery || 0));

  const createMut = useMutation({
    mutationFn: d => raBillAPI.create(d),
    onSuccess: () => {
      toast.success('RA Bill created successfully');
      qc.invalidateQueries(['ra-bills']);
      navigate('/qs/ra-bills');
    },
    onError: e => toast.error(e?.response?.data?.error || 'Creation failed'),
  });

  const handleSubmit = (submitForApproval = false) => {
    const activeItems = items.filter(it => it.current_qty > 0);
    if (!formData.project_id) return toast.error('Select a project site');
    if (!activeItems.length) return toast.error('No work progress entered');
    createMut.mutate({
      ...formData,
      gross_amount: grossTotal,
      gst_amount: gstAmount,
      status: submitForApproval ? 'submitted' : 'draft',
      items: activeItems,
    });
  };

  return (
    <div className="flex flex-col h-screen font-sans text-sm overflow-hidden bg-[#f4f6f9] text-[#404452]">

      {/* ── Top bar ── */}
      <header className="flex-shrink-0 h-14 bg-white border-b border-[#e2e6ec] flex items-center justify-between px-6 z-50 shadow-sm">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="p-1.5 rounded-lg hover:bg-[#f4f6f9] text-[#6a6f7d] hover:text-[#1a1c21] transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <div className="h-5 w-px bg-[#e2e6ec]" />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-[15px] font-semibold text-[#1a1c21] leading-none">
                New Bill Certification
              </h1>
              {formData.project_id && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-50 text-[#0067ff] border border-blue-100">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0067ff] animate-pulse" />
                  {approvedMeasurements?.length || 0} measurements synced
                </span>
              )}
            </div>
            <p className="text-[10px] text-[#8e94a3] mt-0.5 uppercase tracking-wider font-medium">
              Measurement Ledger
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="hidden sm:flex flex-col items-end">
            <span className="text-[10px] font-medium text-[#8e94a3] uppercase tracking-wider">
              Total Payable
            </span>
            <span className="text-[17px] font-bold text-[#0067ff] leading-tight">
              {inr(netPayable)}
            </span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => handleSubmit(false)}
              disabled={createMut.isPending || !formData.project_id}
              className="h-9 px-4 rounded-lg text-xs font-semibold border border-[#d8dce1] bg-white text-[#404452] hover:bg-[#f4f6f9] disabled:opacity-50 transition-colors"
            >
              {createMut.isPending ? 'Saving…' : 'Save as Draft'}
            </button>
            <button
              onClick={() => handleSubmit(true)}
              disabled={createMut.isPending || !formData.project_id}
              className="h-9 px-5 rounded-lg text-xs font-semibold bg-[#0067ff] text-white hover:bg-[#0056d6] disabled:opacity-50 transition-colors shadow-sm"
            >
              Submit for Approval
            </button>
          </div>
        </div>
      </header>

      {/* ── Body ── */}
      <main className="flex-1 flex overflow-hidden">

        {/* ── Left sidebar ── */}
        <aside className="w-[272px] flex-shrink-0 border-r border-[#e2e6ec] flex flex-col bg-white">
          <div className="flex-1 overflow-y-auto p-5 space-y-6 custom-scroll">

            {/* Bill Headers */}
            <section className="space-y-3">
              <h3 className="text-[10px] font-semibold text-[#8e94a3] uppercase tracking-[0.15em]">
                Bill Headers
              </h3>

              <Field label="Project Site *">
                <select
                  className="field-input"
                  value={formData.project_id}
                  onChange={e => set('project_id', e.target.value)}
                >
                  <option value="">— Select —</option>
                  {projects?.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </Field>

              <Field label="Contractor">
                <input
                  className="field-input"
                  value={formData.contractor_name}
                  onChange={e => set('contractor_name', e.target.value)}
                  placeholder="Name of entity"
                />
              </Field>

              <div className="grid grid-cols-2 gap-2">
                <Field label="PAN">
                  <input
                    className="field-input font-mono"
                    value={formData.contractor_pan}
                    onChange={e => set('contractor_pan', e.target.value.toUpperCase())}
                    maxLength={10}
                  />
                </Field>
                <Field label="GSTIN">
                  <input
                    className="field-input font-mono"
                    value={formData.contractor_gstin}
                    onChange={e => set('contractor_gstin', e.target.value.toUpperCase())}
                  />
                </Field>
              </div>

              <Field label="RA Bill No. *">
                <input
                  className="field-input font-mono bg-[#f4f6f9]"
                  value={formData.bill_number}
                  onChange={e => set('bill_number', e.target.value)}
                />
              </Field>
            </section>

            {/* Period */}
            <section className="space-y-3">
              <h3 className="text-[10px] font-semibold text-[#8e94a3] uppercase tracking-[0.15em]">
                Period
              </h3>
              <div className="grid grid-cols-2 gap-2">
                <Field label="From">
                  <input
                    type="date"
                    className="field-input text-[11px]"
                    value={formData.bill_period_from}
                    onChange={e => set('bill_period_from', e.target.value)}
                  />
                </Field>
                <Field label="To">
                  <input
                    type="date"
                    className="field-input text-[11px]"
                    value={formData.bill_period_to}
                    onChange={e => set('bill_period_to', e.target.value)}
                  />
                </Field>
              </div>
            </section>

            {/* Deductions */}
            <section className="space-y-3">
              <h3 className="text-[10px] font-semibold text-[#8e94a3] uppercase tracking-[0.15em]">
                Deductions
              </h3>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Retention %">
                  <input
                    type="number"
                    className="field-input"
                    value={formData.retention_percent}
                    onChange={e => set('retention_percent', parseFloat(e.target.value) || 0)}
                    min={0}
                    max={100}
                  />
                </Field>
                <Field label="GST %">
                  <input
                    type="number"
                    className="field-input"
                    value={formData.gst_percent}
                    onChange={e => set('gst_percent', parseFloat(e.target.value) || 0)}
                    min={0}
                  />
                </Field>
              </div>
              <Field label="Advance Recovery (₹)">
                <input
                  type="number"
                  className="field-input"
                  value={formData.mobilization_advance_recovery}
                  onChange={e =>
                    set('mobilization_advance_recovery', parseFloat(e.target.value) || 0)
                  }
                  min={0}
                />
              </Field>
            </section>
          </div>

          {/* ── Financial summary ── */}
          <div className="flex-shrink-0 border-t border-[#e2e6ec] bg-[#f8fafc] p-4 space-y-2">
            <SummaryRow label="Gross Valuation" value={inr(grossTotal)} />
            <SummaryRow label={`GST (${formData.gst_percent}%)`} value={`+ ${inr(gstAmount)}`} valueClass="text-[#0067ff]" />
            <SummaryRow label={`Retention (${formData.retention_percent}%)`} value={`− ${inr(retentionAmount)}`} valueClass="text-red-500" />
            {parseFloat(formData.mobilization_advance_recovery) > 0 && (
              <SummaryRow label="Adv. Recovery" value={`− ${inr(formData.mobilization_advance_recovery)}`} valueClass="text-red-500" />
            )}
            <div className="border-t border-[#e2e6ec] pt-2 mt-1 flex justify-between items-center">
              <span className="text-xs font-semibold text-[#1a1c21]">Net Payable</span>
              <span className="text-base font-bold text-[#0067ff]">{inr(netPayable)}</span>
            </div>
          </div>
        </aside>

        {/* ── Measurement sheet ── */}
        <section className="flex-1 flex flex-col overflow-hidden bg-white">
          <div className="flex-1 overflow-auto custom-scroll">
            <table className="w-full text-left border-separate border-spacing-0" style={{ minWidth: 780 }}>
              <thead className="sticky top-0 z-20">
                <tr className="bg-[#f8fafc] border-b border-[#e2e6ec]">
                  <th className="px-5 py-3 text-[10px] font-semibold text-[#8e94a3] uppercase tracking-wider border-b border-r border-[#e2e6ec]">
                    Description of Work Item
                  </th>
                  <th className="px-4 py-3 text-[10px] font-semibold text-[#8e94a3] uppercase tracking-wider text-right w-24 border-b border-r border-[#e2e6ec]">
                    BOQ Cap
                  </th>
                  <th className="px-4 py-3 text-[10px] font-semibold text-[#8e94a3] uppercase tracking-wider text-right w-24 border-b border-r border-[#e2e6ec]">
                    Previous
                  </th>
                  <th className="px-4 py-3 text-[10px] font-semibold text-[#0067ff] uppercase tracking-wider text-right w-32 border-b border-r border-[#e2e6ec] bg-blue-50/50">
                    Claim Qty
                  </th>
                  <th className="px-5 py-3 text-[10px] font-semibold text-[#8e94a3] uppercase tracking-wider text-right w-36 border-b border-[#e2e6ec]">
                    Value (₹)
                  </th>
                </tr>
              </thead>
              <tbody>
                {items.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-24 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <Plus className="w-6 h-6 text-slate-300" />
                        <span className="text-xs text-slate-400 font-medium">
                          Select a project to load billable items
                        </span>
                      </div>
                    </td>
                  </tr>
                )}
                {items.map((it, idx) => {
                  const cumQty = (it.prev_certified_qty || 0) + (it.current_qty || 0);
                  const isOver = cumQty > it.boq_qty;
                  return (
                    <tr
                      key={idx}
                      className="group border-b border-[#f0f2f5] hover:bg-[#fbfcfe] transition-colors"
                    >
                      <td className="px-5 py-3 border-r border-[#f0f2f5]">
                        <div
                          className={clsx(
                            'text-[13px] font-medium leading-snug tracking-tight',
                            isOver ? 'text-red-500' : 'text-[#1a1c21]'
                          )}
                        >
                          {it.description}
                          {isOver && (
                            <AlertTriangle
                              size={12}
                              className="inline ml-1 mb-0.5 text-red-400"
                            />
                          )}
                        </div>
                        <div className="mt-1 flex items-center gap-2 text-[10px] text-[#8e94a3]">
                          <span className="border border-[#e2e6ec] px-1.5 py-0.5 rounded text-[9px] uppercase font-medium">
                            {it.unit}
                          </span>
                          <span>Unit Rate: ₹{Number(it.rate).toLocaleString('en-IN')}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-[11px] text-slate-400 border-r border-[#f0f2f5]">
                        {(it.boq_qty || 0).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-[11px] text-slate-400 border-r border-[#f0f2f5]">
                        {(it.prev_certified_qty || 0).toLocaleString()}
                      </td>
                      <td className="px-4 py-3 text-right border-r border-[#f0f2f5] bg-blue-50/20">
                        <input
                          type="number"
                          className={clsx(
                            'w-full h-8 text-right bg-white border rounded-lg px-2 text-sm font-semibold outline-none transition-all',
                            isOver
                              ? 'border-red-300 text-red-500 focus:ring-2 focus:ring-red-100'
                              : 'border-[#d8dce1] text-[#0067ff] focus:border-[#0067ff] focus:ring-2 focus:ring-blue-50'
                          )}
                          value={it.current_qty}
                          onChange={e => handleQtyChange(idx, e.target.value)}
                          min={0}
                        />
                      </td>
                      <td className="px-5 py-3 text-right font-mono text-[13px] font-semibold text-[#404452] group-hover:text-[#0067ff] transition-colors">
                        {inr(it.amount || 0)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Remarks */}
          <div className="flex-shrink-0 border-t border-[#e2e6ec] bg-[#f8fafc] px-5 py-3">
            <div className="flex items-center gap-3">
              <span className="text-[10px] font-semibold text-[#8e94a3] uppercase tracking-wider whitespace-nowrap">
                Notes:
              </span>
              <input
                className="flex-1 bg-transparent border-none text-xs text-[#404452] outline-none placeholder:text-[#b0b5c3] placeholder:italic"
                placeholder="Annotate measurement discrepancies or physical progress details…"
                value={formData.remarks}
                onChange={e => set('remarks', e.target.value)}
              />
            </div>
          </div>
        </section>
      </main>

      <style>{`
        .field-input {
          width: 100%;
          height: 32px;
          border: 1px solid #d8dce1;
          border-radius: 6px;
          padding: 0 8px;
          font-size: 12px;
          color: #1a1c21;
          background: #ffffff;
          outline: none;
          transition: border-color 0.15s;
        }
        .field-input:focus { border-color: #0067ff; box-shadow: 0 0 0 3px #e8f0ff; }
        input::-webkit-outer-spin-button, input::-webkit-inner-spin-button { -webkit-appearance: none; }
        input[type=number] { -moz-appearance: textfield; }
        .custom-scroll::-webkit-scrollbar { width: 4px; height: 4px; }
        .custom-scroll::-webkit-scrollbar-track { background: transparent; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #d8dce1; border-radius: 10px; }
      `}</style>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="space-y-1">
      <label className="block text-[11px] font-medium text-[#6a6f7d]">{label}</label>
      {children}
    </div>
  );
}

function SummaryRow({ label, value, valueClass = 'text-[#1a1c21]' }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-[11px] text-[#6a6f7d]">{label}</span>
      <span className={clsx('text-[11px] font-semibold font-mono', valueClass)}>{value}</span>
    </div>
  );
}
