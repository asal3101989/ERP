// src/pages/qs/RABillDetail.jsx
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import {
  ArrowLeft, Download, CheckCircle2, Building2,
  User, Calendar, Banknote, ShieldCheck,
  Printer, Layers, FileText, XCircle,
} from 'lucide-react';
import api, { raBillAPI } from '../../api/client';
import { clsx } from 'clsx';
import dayjs from 'dayjs';

const inr = v => `₹${Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 0 })}`;

const STATUS_MAP = {
  submitted:       { label: 'Submitted',       cls: 'bg-amber-50 text-amber-600 border-amber-200' },
  qs_review:       { label: 'QS Review',       cls: 'bg-blue-50 text-blue-600 border-blue-200' },
  pm_approval:     { label: 'PM Approval',     cls: 'bg-violet-50 text-violet-600 border-violet-200' },
  accounts_verify: { label: 'Accounts Verify', cls: 'bg-indigo-50 text-indigo-600 border-indigo-200' },
  certified:       { label: 'Certified',       cls: 'bg-emerald-50 text-emerald-600 border-emerald-200' },
  rejected:        { label: 'Rejected',        cls: 'bg-red-50 text-red-500 border-red-200' },
  paid:            { label: 'Paid',            cls: 'bg-teal-50 text-teal-600 border-teal-200' },
};

const STEPS = [
  { key: 'submitted',       label: 'Field' },
  { key: 'qs_review',       label: 'QS' },
  { key: 'pm_approval',     label: 'PM' },
  { key: 'accounts_verify', label: 'Accounts' },
  { key: 'certified',       label: 'Certified' },
];

export default function RABillDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const { data: b, isLoading } = useQuery({
    queryKey: ['ra-bill', id],
    queryFn: () => api.get(`/ra-bills/${id}`).then(r => r.data),
  });

  const approveMut = useMutation({
    mutationFn: () => raBillAPI.approve(b.id, { action: 'approve' }),
    onSuccess: () => {
      toast.success('Approved successfully');
      // FIX: use object form for invalidateQueries (TanStack Query v5)
      qc.invalidateQueries({ queryKey: ['ra-bill', id] });
    },
    onError: e => toast.error(e?.response?.data?.error || 'Approval failed'),
  });

  const rejectMut = useMutation({
    mutationFn: () => raBillAPI.approve(b.id, { action: 'reject', remarks: 'Manually rejected' }),
    onSuccess: () => {
      toast.success('Bill rejected');
      qc.invalidateQueries({ queryKey: ['ra-bill', id] });
    },
    onError: e => toast.error(e?.response?.data?.error || 'Failed'),
  });

  if (isLoading || !b) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[60vh]">
        <div className="text-xs text-[#8e94a3]">Loading bill…</div>
      </div>
    );
  }

  const st = STATUS_MAP[b.status] || STATUS_MAP.submitted;
  const currentIdx = STEPS.findIndex(s => s.key === b.status);
  const canActOn = ['submitted', 'qs_review', 'pm_approval', 'accounts_verify'].includes(b.status);

  const deductions = [
    { label: 'Retention', value: b.retention_amount },
    { label: 'Advance Recovery', value: b.mobilization_advance_recovery },
    {
      label: 'Material Recovery',
      value: Number(b.material_recovery_cement || 0) + Number(b.material_recovery_steel || 0),
    },
    { label: 'TDS', value: b.tds_amount },
  ].filter(d => parseFloat(d.value) > 0);

  return (
    <div className="p-6 space-y-5 bg-[#f4f6f9] min-h-screen font-sans text-sm">

      {/* ── Header ── */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="p-1.5 rounded-lg border border-[#e2e6ec] bg-white hover:bg-[#f4f6f9] text-[#6a6f7d] transition-colors shadow-sm"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-[17px] font-semibold text-[#1a1c21] font-mono uppercase tracking-tight">
                {b.bill_number}
              </h1>
              <span
                className={clsx(
                  'inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-semibold border',
                  st.cls
                )}
              >
                {st.label}
              </span>
            </div>
            <div className="flex items-center gap-3 mt-1 text-[10px] text-[#8e94a3]">
              <span className="flex items-center gap-1">
                <Building2 size={11} /> {b.contractor_name}
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Calendar size={11} /> {dayjs(b.bill_date).format('DD MMM YYYY')}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button className="p-2 rounded-lg border border-[#e2e6ec] bg-white text-[#6a6f7d] hover:text-[#1a1c21] transition-colors shadow-sm">
            <Printer size={17} />
          </button>
          <button className="p-2 rounded-lg border border-[#e2e6ec] bg-white text-[#6a6f7d] hover:text-[#1a1c21] transition-colors shadow-sm">
            <Download size={17} />
          </button>
          {canActOn && (
            <>
              <button
                onClick={() => rejectMut.mutate()}
                disabled={rejectMut.isPending}
                className="px-4 h-9 rounded-lg text-xs font-semibold border border-red-200 bg-red-50 text-red-500 hover:bg-red-100 transition-colors disabled:opacity-50"
              >
                Reject
              </button>
              <button
                onClick={() => approveMut.mutate()}
                disabled={approveMut.isPending}
                className="px-5 h-9 rounded-lg text-xs font-semibold bg-[#0067ff] text-white hover:bg-[#0056d6] transition-colors shadow-sm disabled:opacity-50"
              >
                {approveMut.isPending ? 'Processing…' : 'Approve'}
              </button>
            </>
          )}
        </div>
      </div>

      {/* ── Body grid ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

        {/* Left col */}
        <div className="lg:col-span-2 space-y-5">

          {/* Lifecycle stepper */}
          <div className="bg-white rounded-2xl border border-[#e2e6ec] shadow-sm p-5">
            <h2 className="text-[10px] font-semibold text-[#8e94a3] uppercase tracking-wider mb-4">
              Approval Lifecycle
            </h2>
            <div className="flex items-center">
              {STEPS.map((s, i) => {
                const passed = i < currentIdx;
                const active = i === currentIdx;
                return (
                  <React.Fragment key={s.key}>
                    <div className="flex flex-col items-center flex-1">
                      <div
                        className={clsx(
                          'w-7 h-7 rounded-full border-2 flex items-center justify-center text-[10px] font-semibold transition-all',
                          passed
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : active
                            ? 'bg-[#0067ff] border-[#0067ff] text-white ring-4 ring-blue-50'
                            : 'bg-white border-[#d8dce1] text-[#8e94a3]'
                        )}
                      >
                        {passed ? <CheckCircle2 size={14} /> : i + 1}
                      </div>
                      <div
                        className={clsx(
                          'text-[9px] font-semibold uppercase tracking-wider mt-1.5',
                          active
                            ? 'text-[#0067ff]'
                            : passed
                            ? 'text-emerald-500'
                            : 'text-[#8e94a3]'
                        )}
                      >
                        {s.label}
                      </div>
                    </div>
                    {i < STEPS.length - 1 && (
                      <div
                        className={clsx(
                          'flex-[2] h-px -mt-5',
                          passed ? 'bg-emerald-400' : 'bg-[#e2e6ec]'
                        )}
                      />
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>

          {/* Line items */}
          <div className="bg-white rounded-2xl border border-[#e2e6ec] shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#e2e6ec] flex items-center gap-2">
              <Layers size={16} className="text-[#0067ff]" />
              <h2 className="text-xs font-semibold text-[#1a1c21] uppercase tracking-wide">
                Line Item Breakdown
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[12px]">
                <thead>
                  <tr className="bg-[#f8fafc] border-b border-[#e2e6ec]">
                    {['Specification', 'Previous', 'Current', 'Value'].map((h, i) => (
                      <th
                        key={h}
                        className={clsx(
                          'px-5 py-2.5 text-[10px] font-semibold text-[#8e94a3] uppercase tracking-wider',
                          i > 0 ? 'text-right' : 'text-left',
                          i === 2 && 'bg-blue-50/50 text-[#0067ff]'
                        )}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f0f2f5]">
                  {/* FIX: b.items could be undefined — safe fallback added */}
                  {(b.items || []).map((it, idx) => (
                    <tr key={idx} className="hover:bg-[#f8fafc] transition-colors">
                      <td className="px-5 py-3">
                        <div className="font-medium text-[#1a1c21] leading-snug">
                          {it.description}
                        </div>
                        <div className="text-[10px] text-[#8e94a3] mt-0.5 uppercase">
                          {it.unit} · Rate: {inr(it.rate)}
                        </div>
                      </td>
                      <td className="px-5 py-3 text-right font-mono text-[#8e94a3]">
                        {(it.prev_certified_qty || 0).toLocaleString()}
                      </td>
                      <td className="px-5 py-3 text-right font-mono font-semibold text-[#0067ff] bg-blue-50/20">
                        {(it.current_qty || 0).toLocaleString()}
                      </td>
                      <td className="px-5 py-3 text-right font-mono font-semibold text-[#1a1c21]">
                        {inr(it.amount || it.current_qty * it.rate)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right col */}
        <div className="space-y-4">

          {/* Payment ledger */}
          <div className="bg-white rounded-2xl border border-[#e2e6ec] shadow-sm p-5 space-y-4">
            <div className="flex items-center gap-2">
              <Banknote className="w-4 h-4 text-emerald-600" />
              <h3 className="text-xs font-semibold text-[#1a1c21] uppercase tracking-wide">
                Payment Ledger
              </h3>
            </div>

            <div className="space-y-2.5">
              <LedgerRow label="Gross Release" value={inr(b.gross_amount)} />
              <LedgerRow
                label={`GST @${b.gst_rate}%`}
                value={`+ ${inr(b.gst_amount)}`}
                valueClass="text-[#0067ff]"
              />

              {deductions.length > 0 && (
                <div className="border-t border-[#f0f2f5] pt-2.5 space-y-2">
                  {deductions.map((d, i) => (
                    <LedgerRow
                      key={i}
                      label={d.label}
                      value={`− ${inr(d.value)}`}
                      valueClass="text-red-500"
                    />
                  ))}
                </div>
              )}

              <div className="border-t border-[#e2e6ec] pt-3 mt-1">
                <div className="text-[10px] font-medium text-[#8e94a3] uppercase tracking-wider mb-1">
                  Total Certified Disbursement
                </div>
                <div className="text-[26px] font-bold text-emerald-600 leading-none font-mono">
                  {inr(b.net_payable)}
                </div>
              </div>
            </div>
          </div>

          {/* Meta */}
          <div className="bg-white rounded-2xl border border-[#e2e6ec] shadow-sm p-4 space-y-3">
            <div className="flex items-center gap-2 text-[11px] text-[#6a6f7d]">
              <User size={13} />
              <span>Submitted by</span>
              <span className="font-semibold text-[#1a1c21] ml-auto">
                {b.submitted_by_name || 'Admin'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-[#6a6f7d]">
              <FileText size={13} />
              <span>Bill date</span>
              <span className="font-semibold text-[#1a1c21] ml-auto">
                {dayjs(b.bill_date).format('DD MMM YYYY')}
              </span>
            </div>
            {b.remarks && (
              <div className="mt-1 bg-amber-50 border border-amber-100 rounded-xl p-3 text-[11px] text-amber-700 italic leading-relaxed">
                "{b.remarks}"
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function LedgerRow({ label, value, valueClass = 'text-[#1a1c21]' }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[11px] text-[#6a6f7d]">{label}</span>
      <span className={clsx('text-[11px] font-semibold font-mono', valueClass)}>{value}</span>
    </div>
  );
}
