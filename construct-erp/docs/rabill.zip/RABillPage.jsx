// src/pages/qs/RABillPage.jsx
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Receipt, CheckCircle2, ShieldCheck,
  TrendingUp, Building2, Calendar,
  FileText, Download, Eye,
  XCircle, Wallet2, BarChart3,
} from 'lucide-react';
import { raBillAPI, projectAPI, default as api } from '../../api/client';
import toast from 'react-hot-toast';
import { clsx } from 'clsx';
import dayjs from 'dayjs';
import { Link, useNavigate } from 'react-router-dom';
import DataToolbar from '../../components/common/DataToolbar';
import TableActions from '../../components/common/TableActions';

const inr = v => `₹${Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 0 })}`;
const inrCompact = v =>
  v >= 1e7
    ? `₹${(v / 1e7).toFixed(2)} Cr`
    : v >= 1e5
    ? `₹${(v / 1e5).toFixed(1)} L`
    : inr(v);

const STATUS_CONFIG = {
  draft:           { label: 'Draft',            cls: 'bg-[#f4f6f9] text-[#6a6f7d] border-[#d8dce1]',     Icon: FileText },
  submitted:       { label: 'Submitted',         cls: 'bg-amber-50 text-amber-600 border-amber-200',        Icon: FileText },
  verified:        { label: 'Verified (QS)',     cls: 'bg-blue-50 text-blue-600 border-blue-200',           Icon: ShieldCheck },
  certified:       { label: 'Certified',         cls: 'bg-emerald-50 text-emerald-600 border-emerald-200',  Icon: CheckCircle2 },
  // FIX: 'Returned' is misleading — using 'Rejected' to match backend status key
  rejected:        { label: 'Rejected',          cls: 'bg-red-50 text-red-500 border-red-200',              Icon: XCircle },
};

export default function RABillPage() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [filterProject, setFilterProject] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  const { data: bills, isLoading } = useQuery({
    queryKey: ['ra-bills', filterProject],
    queryFn: () =>
      raBillAPI
        .list(filterProject !== 'all' ? { project_id: filterProject } : {})
        .then(r => r.data.data),
  });

  const { data: projects } = useQuery({
    queryKey: ['projects'],
    queryFn: () => projectAPI.list().then(r => r.data.data),
  });

  const verifyMut = useMutation({
    mutationFn: id => raBillAPI.verify(id),
    onSuccess: () => {
      toast.success('Bill verified');
      // FIX: invalidateQueries needs object form with queryKey for v5 compatibility
      qc.invalidateQueries({ queryKey: ['ra-bills'] });
    },
    onError: () => toast.error('Verification failed'),
  });

  const deleteMut = useMutation({
    mutationFn: id => api.delete(`/ra-bills/${id}`),
    onSuccess: () => {
      toast.success('Bill deleted');
      qc.invalidateQueries({ queryKey: ['ra-bills'] });
    },
    onError: () => toast.error('Failed to delete RA Bill'),
  });

  const filtered = (bills || []).filter(
    b => filterStatus === 'all' || b.status === filterStatus
  );

  const totalRevenue = (bills || []).reduce((s, b) => s + parseFloat(b.gross_amount || 0), 0);
  const totalRetention = (bills || []).reduce((s, b) => s + parseFloat(b.retention_amount || 0), 0);
  const certifiedCount = (bills || []).filter(b => b.status === 'certified').length;
  const pendingCount = (bills || []).filter(b =>
    ['submitted', 'verified'].includes(b.status)
  ).length;

  return (
    <div className="p-6 space-y-5 bg-[#f4f6f9] min-h-screen font-sans">

      {/* ── Header ── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-white border border-[#e2e6ec] flex items-center justify-center shadow-sm">
            <Receipt className="w-5 h-5 text-[#0067ff]" />
          </div>
          <div>
            <h1 className="text-base font-semibold text-[#1a1c21]">Client Billing (Revenue)</h1>
            <p className="text-[10px] text-[#8e94a3] font-medium uppercase tracking-wider">
              Running Account Bills · Progress Certification
            </p>
          </div>
        </div>
        <DataToolbar
          data={bills}
          fileName={`RA_Bills_${filterProject}`}
          onAdd={() => navigate('/qs/ra-bills/new')}
          addLabel="New RA Bill"
        />
      </div>

      {/* ── Stat cards ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Revenue" value={inrCompact(totalRevenue)} icon={TrendingUp} accent="text-[#0067ff]" />
        <StatCard label="Retention Held" value={inrCompact(totalRetention)} icon={Wallet2} accent="text-amber-500" />
        <StatCard label="Certified" value={certifiedCount} icon={ShieldCheck} accent="text-emerald-600" />
        <StatCard label="In Pipeline" value={pendingCount} icon={BarChart3} accent="text-[#8e94a3]" />
      </div>

      {/* ── Filters ── */}
      <div className="flex flex-wrap gap-3 items-center justify-between">
        <div className="flex gap-1 p-1 bg-white border border-[#e2e6ec] rounded-xl shadow-sm">
          {[
            { key: 'all', label: 'All Bills' },
            { key: 'submitted', label: 'Pending' },
            { key: 'certified', label: 'Certified' },
            { key: 'rejected', label: 'Rejected' },
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setFilterStatus(tab.key)}
              className={clsx(
                'px-4 py-1.5 rounded-lg text-[11px] font-medium transition-all',
                filterStatus === tab.key
                  ? 'bg-[#0067ff] text-white shadow-sm'
                  : 'text-[#6a6f7d] hover:text-[#1a1c21] hover:bg-[#f4f6f9]'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <select
          className="h-9 px-3 border border-[#d8dce1] rounded-xl text-[11px] font-medium bg-white text-[#404452] outline-none focus:border-[#0067ff] w-60 shadow-sm"
          value={filterProject}
          onChange={e => setFilterProject(e.target.value)}
        >
          <option value="all">All Project Sites</option>
          {projects?.map(p => (
            <option key={p.id} value={p.id}>{p.name}</option>
          ))}
        </select>
      </div>

      {/* ── Table ── */}
      <div className="bg-white rounded-2xl border border-[#e2e6ec] overflow-hidden shadow-sm">
        <table className="w-full text-sm text-left">
          <thead>
            <tr className="border-b border-[#e2e6ec] bg-[#f8fafc]">
              {['Bill Ref & Site', 'Gross Value', 'Deductions', 'Net Discharge', 'Status', 'Actions'].map(
                (h, i) => (
                  <th
                    key={h}
                    className={clsx(
                      'px-5 py-3 text-[10px] font-semibold text-[#8e94a3] uppercase tracking-wider',
                      i >= 3 && 'text-right'
                    )}
                  >
                    {h}
                  </th>
                )
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-[#f0f2f5]">
            {isLoading && (
              <tr>
                <td colSpan={6} className="py-16 text-center text-xs text-[#8e94a3]">
                  Loading bills…
                </td>
              </tr>
            )}
            {!isLoading && filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="py-16 text-center text-xs text-[#8e94a3]">
                  No bills found
                </td>
              </tr>
            )}
            {filtered.map(bill => {
              const cfg = STATUS_CONFIG[bill.status] || STATUS_CONFIG.submitted;
              const IconComp = cfg.Icon;
              const hasAdvRecovery = parseFloat(bill.mobilization_advance_recovery) > 0;

              return (
                <tr key={bill.id} className="hover:bg-[#f8fafc] transition-colors group">
                  {/* Bill ref */}
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-[#f4f6f9] border border-[#e2e6ec] flex items-center justify-center text-[#0067ff] flex-shrink-0 group-hover:border-[#0067ff]/30 transition-colors">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-[13px] font-semibold text-[#1a1c21] font-mono uppercase">
                          {bill.bill_number}
                        </div>
                        <div className="flex items-center gap-1.5 mt-0.5 text-[10px] text-[#8e94a3]">
                          <Building2 className="w-3 h-3" />
                          <span>{bill.project_name}</span>
                          <span className="text-[#d8dce1]">·</span>
                          <Calendar className="w-3 h-3" />
                          <span>{dayjs(bill.bill_date).format('DD MMM YYYY')}</span>
                        </div>
                      </div>
                    </div>
                  </td>

                  {/* Gross */}
                  <td className="px-5 py-4">
                    <div className="text-[13px] font-semibold text-[#1a1c21] font-mono">
                      {inr(bill.gross_amount)}
                    </div>
                    <div className="text-[10px] text-[#8e94a3] mt-0.5">BOQ certified value</div>
                  </td>

                  {/* Deductions */}
                  <td className="px-5 py-4">
                    <div className="space-y-1">
                      <DeductRow
                        label={`Retention (${bill.retention_percent}%)`}
                        value={inr(bill.retention_amount)}
                      />
                      {hasAdvRecovery && (
                        <DeductRow
                          label="Advance Recovery"
                          value={inr(bill.mobilization_advance_recovery)}
                          color="text-amber-500"
                        />
                      )}
                    </div>
                  </td>

                  {/* Net */}
                  <td className="px-5 py-4 text-right">
                    <div className="text-[15px] font-bold text-emerald-600 font-mono">
                      {inr(bill.net_payable)}
                    </div>
                    <div className="text-[10px] text-[#8e94a3] mt-0.5">incl. taxes</div>
                  </td>

                  {/* Status */}
                  <td className="px-5 py-4 text-right">
                    <span
                      className={clsx(
                        'inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-semibold border',
                        cfg.cls
                      )}
                    >
                      <IconComp className="w-3 h-3" />
                      {cfg.label}
                    </span>
                    {bill.status === 'verified' && (
                      <div className="text-[9px] text-[#8e94a3] mt-1 text-right">
                        {bill.verified_by_name || 'QS Team'}
                      </div>
                    )}
                  </td>

                  {/* Actions */}
                  <td className="px-5 py-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {bill.status === 'submitted' && (
                        <button
                          onClick={() => verifyMut.mutate(bill.id)}
                          className="px-3 py-1.5 bg-[#0067ff] text-white text-[10px] font-semibold rounded-lg hover:bg-[#0056d6] transition-colors"
                        >
                          Verify
                        </button>
                      )}
                      <Link
                        to={`/qs/ra-bills/${bill.id}`}
                        className="p-2 rounded-lg border border-[#e2e6ec] text-[#6a6f7d] hover:text-[#0067ff] hover:border-[#0067ff]/30 transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </Link>
                      <button className="p-2 rounded-lg border border-[#e2e6ec] text-[#6a6f7d] hover:text-[#0067ff] hover:border-[#0067ff]/30 transition-colors">
                        <Download className="w-4 h-4" />
                      </button>
                      <TableActions disableEdit onDelete={() => deleteMut.mutate(bill.id)} />
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, accent }) {
  return (
    <div className="bg-white border border-[#e2e6ec] rounded-xl p-4 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[10px] font-medium text-[#8e94a3] uppercase tracking-wider">{label}</span>
        <Icon className={clsx('w-4 h-4', accent)} />
      </div>
      <div className="text-[22px] font-bold text-[#1a1c21] leading-none">{value}</div>
    </div>
  );
}

function DeductRow({ label, value, color = 'text-red-500' }) {
  return (
    <div className={clsx('flex items-center justify-between text-[10px] font-medium', color)}>
      <span>{label}</span>
      <span className="font-mono ml-3">−{value}</span>
    </div>
  );
}
